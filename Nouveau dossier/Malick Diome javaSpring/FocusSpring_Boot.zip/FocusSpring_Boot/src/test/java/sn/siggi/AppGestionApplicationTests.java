package sn.siggi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppGestionApplicationTests {

	@Test
	void contextLoads() {
	}

}

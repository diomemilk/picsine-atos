/**
 * 
 */
package sn.siggi.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import sn.siggi.domaine.Departement;

/**
 * @author nabyFall
 *
 */
public interface DepartementRepository extends JpaRepository<Departement, Integer>{

}
